Bot or not accounts Detection
Authors:
I.	Introduction
There are millions of twitter accounts all over the world. However, many of them are not used by actual people and these that are controlled by robots or software are called to be bot. Although plenty of bots on twitter are benign, there are still bad bots that mislead, exploit and manipulate online conversations with rumors, spam, misinformation and slander. Therefore, it is very useful to explore some algorithms for detecting whether these accounts are bot or not. In this project, we are going to compare the performances of two kinds of machine learning algorithms for detecting accounts “bot or not”. 
II.	Motivation
Since some bad 


III.	Related Work
IV.	Data. 
Bots: PhotoLab Bot@Photolab_Bot,  Mobilised @mtm, LOUDBOT@LOUDBOT, AR Herald @ARherald, AugmentedAdvertsing @AugmentedAdvert, Debit Card@NeedADebitCard, Hurricane Sandy Help @SandyAid, Procrastibot@Procrastibot, It’s Spelt Caesar @itsspeltcaesar, Hundred Zeros@HundredZeros, Dear Assistant@DearAssistant, What the Fare@WhatTheFare, Museum Bot@MuseumBot, Pentametron@pentametron, Grammar Police@_grammar_, Pixel Sorter @pixelsorter, Netfix Bot@netflix_bot, Earthquake Robot@earthquakeBot, everyword@everyword, Thinkpiece Bot@thinkpiecebot,
Congress-edits@congressedits, Great Artist@greatartbot, olivia taters@oliviataters, moth generator@mothgenerator, MoMA Bot@MoMARobot, blah future@blahfuture, NYPD edits@NYPDedits, it’s always 4:20 @420worldclock, balh future@blahfuture, Two Headliens@TwoHeadlines, poem.exe @poem_exe, censusAmericans@censusAmericans, Holiday Bot@holidaybot4000, Countdown bot@lettergamebot, JustDiedBot @JustDiedBot, NotInventedHere@NotInventedHere, Perline Egg Craft@perlineggcraft, Botstructions@botstructions, TNY Poetry@tnypoetry, Rules for the Day @RulesForTheDay.
Doodlybot@Doodlybot, phase↝chase @phasechase, NYT Anonymous@NYTAnon, RealDonaldContext@realDonaldCntxt, Good Music Recs@songchoicebot, Ominous Studies@OminousStudies, Kanye Jordan @kanyejordan, Sealth Mountain@StealthMountain, dronesweetie@dronesweetie, DSCOVR:EPIC @dscovr_epic. 
Not Bot: Donald J.Trump @realDonaldTrump, 

V.	Algorithms plan to use



